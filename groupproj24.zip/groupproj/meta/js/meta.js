$(function() {
    $('.menu').on("click", function() {
        $('responsive').add()
    });
})
